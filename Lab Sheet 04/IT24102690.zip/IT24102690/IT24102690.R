setwd("C:\\Users\\User\\Desktop\\IT24102690")


#Q1)
branch_data <- read.csv("Exercise.txt", header = TRUE)


#Q2)
head (branch_data)
sapply (branch_data, class)

#Q3)
boxplot(branch_data$Sales,
        main = "Boxplot of Sales",
        ylab = "Sales",
        col = "lightblue")

#Q4)
print(fivenum(branch_data$Advertising))
IQR(branch_data$Advertising)


#Q5
get.outliers <- function(z) {
  q1 <- quantile(z, 0.25)    
  q3 <- quantile(z, 0.75)    
  iqr <- q3 - q1             
  
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr 
  
  outliers <- z[z < lower_bound | z > upper_bound]
  return(outliers)
}
years_outliers <- find_outliers(branch_data$Years)

cat("outliers in 'Years' variable:\n")
if (length(years_outliers)==0){
  cat("No outliers found \n")
}else{
  print (years_outliers)
}


